class Module
  public :undef_method
end
