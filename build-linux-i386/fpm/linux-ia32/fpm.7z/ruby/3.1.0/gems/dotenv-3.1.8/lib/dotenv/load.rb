require "dotenv"

defined?(Dotenv::Rails) ? Dotenv::Rails.load : Dotenv.load
