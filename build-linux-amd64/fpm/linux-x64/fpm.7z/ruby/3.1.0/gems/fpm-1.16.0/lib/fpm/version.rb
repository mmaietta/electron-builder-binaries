module FPM
  VERSION = "1.16.0"
end
