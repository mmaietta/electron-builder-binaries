class Module
  public :define_method
end
