# NSIS Wrapper for Windows (PowerShell)
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$env:NSISDIR = Join-Path $ScriptDir "share\nsis"
$Makensis = Join-Path $ScriptDir "win32\Bin\makensis.exe"
& $Makensis @args
exit $LASTEXITCODE
