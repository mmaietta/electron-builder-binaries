# NSIS Cross-Platform Bundle

This bundle contains NSIS (Nullsoft Scriptable Install System) binaries for multiple platforms.

## Contents

- **Windows**: `windows/makensis.exe` (official pre-built binary)
- **Linux**: `linux/makensis` (native ELF binary, compiled from source)
- **macOS**: `mac/makensis` (native Mach-O binary, compiled from source)
- **NSIS Data**: `windows/` (Contrib, Include, Plugins, Stubs)
- **Universal Wrapper**: `makensis` (auto-detects platform, sets `NSISDIR`) [.cmd and .ps1 versions for Windows]

## Quick Start

### Option 1: Use Universal Wrapper (Recommended)

The wrapper automatically detects your platform and sets `NSISDIR`:

```bash
# Linux/macOS/Git Bash
./makensis your-script.nsi

# Windows CMD
makensis.cmd your-script.nsi

# Windows PowerShell
.\makensis.ps1 your-script.nsi
```

### Option 2: Use Platform-Specific Binary

```bash
# Set NSISDIR manually
export NSISDIR="$(pwd)/windows"

# Run platform-specific binary
./windows/makensis.exe your-script.nsi  # Windows
./linux/makensis your-script.nsi         # Linux
./mac/makensis your-script.nsi           # macOS
```

## Version Information

- NSIS Version: 3.11
- Branch/Tag: v311
- Build Date: 2026-01-24T01:25:24Z

## Included Plugins

This bundle includes 8 additional community plugins:

1. NsProcess - Process management
2. UAC - User Account Control
3. WinShell - Shell integration
4. NsJSON - JSON parsing
5. NsArray - Array support
6. INetC - HTTP client
7. NsisMultiUser - Multi-user installs
8. StdUtils - Standard utilities

## Environment Variables

- **NSISDIR**: Path to NSIS data directory (auto-set by wrapper)
- Set manually if needed: `export NSISDIR=/path/to/windows`

## More Information

- NSIS Documentation: https://nsis.sourceforge.io/Docs/
- Plugin Repository: https://nsis.sourceforge.io/Category:Plugins
