# =============================================================
# NSIS Windows PowerShell Entrypoint (CI-safe)
# =============================================================

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Ensure Windows-style paths
if ($ScriptDir -notmatch '^[a-zA-Z]:[\\/]' -and $ScriptDir -match '^/([a-zA-Z])/(.*)') {
    $ScriptDir = "$($matches[1]):\$($matches[2] -replace '/', '\')"
}

$env:NSISDIR = Join-Path $ScriptDir "windows"
$Makensis   = Join-Path $env:NSISDIR "makensis.exe"
if (-not (Test-Path $Makensis)) {
    Write-Error "makensis.exe not found at: $Makensis"
    exit 1
}

Unblock-File $Makensis
& "$Makensis" @args

# Exit with same code
exit $LASTEXITCODE
