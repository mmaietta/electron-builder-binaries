# NSIS Wrapper for Windows (PowerShell)
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$env:NSISDIR = Join-Path $ScriptDir "vendor"
$Makensis = Join-Path $ScriptDir "vendor\makensis\makensis.exe"
& $Makensis @args
exit $LASTEXITCODE
