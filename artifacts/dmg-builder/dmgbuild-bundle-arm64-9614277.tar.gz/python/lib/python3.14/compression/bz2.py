import bz2
__doc__ = bz2.__doc__
del bz2

from bz2 import *
