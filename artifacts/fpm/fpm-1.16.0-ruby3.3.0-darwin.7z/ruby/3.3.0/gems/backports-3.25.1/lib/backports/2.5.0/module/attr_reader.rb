class Module
  public :attr_reader
end
