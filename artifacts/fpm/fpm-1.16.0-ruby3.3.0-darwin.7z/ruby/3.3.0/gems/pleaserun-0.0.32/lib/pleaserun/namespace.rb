module PleaseRun
  module Platform; end
  module User; end
end
