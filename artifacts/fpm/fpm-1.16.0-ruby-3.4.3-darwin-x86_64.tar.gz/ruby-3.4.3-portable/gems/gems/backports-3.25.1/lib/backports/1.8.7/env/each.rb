require 'backports/tools/make_block_optional'

Backports.make_block_optional ENV, :each, :test_on => ENV
