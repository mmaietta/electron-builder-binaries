class Module
  public :attr
end
