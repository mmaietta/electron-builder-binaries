class Module
  public :attr_writer
end
