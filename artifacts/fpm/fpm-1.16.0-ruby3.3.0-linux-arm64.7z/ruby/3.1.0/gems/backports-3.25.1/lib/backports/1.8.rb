# require this file to load all the backports of the Ruby 1.8.x line
require 'backports/1.8.7'
