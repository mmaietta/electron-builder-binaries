class << Process
  public :exec
end
