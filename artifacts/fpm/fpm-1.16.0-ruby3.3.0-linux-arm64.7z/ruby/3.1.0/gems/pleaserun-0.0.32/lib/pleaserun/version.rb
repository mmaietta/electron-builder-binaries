module PleaseRun
  VERSION = "0.0.32"
end
