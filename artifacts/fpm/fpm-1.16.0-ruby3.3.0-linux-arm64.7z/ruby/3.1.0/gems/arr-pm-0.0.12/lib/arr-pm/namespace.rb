class RPM
  class File; end
end

module ArrPM
  module V2
    class Package; end
  end
end
