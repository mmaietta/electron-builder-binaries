# require this file to load all the backports of Ruby 2.6 and below
require 'backports/2.6.0'
