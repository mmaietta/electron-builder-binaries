require File.join(File.dirname(__FILE__), "namespace")
require File.join(File.dirname(__FILE__), "requires")

class RPM::Conflicts < RPM::Requires
end
