class Module
  public :remove_method
end
