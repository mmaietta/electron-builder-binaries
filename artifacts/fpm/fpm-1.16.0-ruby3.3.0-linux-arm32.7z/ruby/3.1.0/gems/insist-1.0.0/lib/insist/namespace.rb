class Insist; end
