class Module
  public :alias_method
end
