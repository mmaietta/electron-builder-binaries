class Module
  public :attr_accessor
end
