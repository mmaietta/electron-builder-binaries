module Dotenv
  VERSION = "3.1.8".freeze
end
