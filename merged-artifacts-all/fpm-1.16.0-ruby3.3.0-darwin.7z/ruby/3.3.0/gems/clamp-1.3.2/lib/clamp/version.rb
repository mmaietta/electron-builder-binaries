# frozen_string_literal: true

module Clamp
  VERSION = "1.3.2".freeze
end
